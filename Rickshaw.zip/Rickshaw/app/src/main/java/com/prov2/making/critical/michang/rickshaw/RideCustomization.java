package com.prov2.making.critical.michang.rickshaw;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Timestamp;


public class RideCustomization extends AppCompatActivity implements View.OnClickListener{

    public String dest;
    public Button requestRide;
    public CustomRide myOrder;
    private static final String TAG = "RideCustomization";

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private DatabaseReference mRideReqRef;
    private ValueEventListener mRideReqRefListener;
    private FirebaseAuth.AuthStateListener mAuthListener;

    private void returnToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private boolean bmw_bold = false;
    private boolean tesla_bold = false;
    private boolean honda_bold = false;
    private boolean casual_bold = false;
    private boolean suit_bold = false;
    private boolean onesie_bold = false;
    private boolean laughter_bold = false;
    private boolean smile_bold = false;
    private boolean frown_bold = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_customization);

        requestRide = (Button) findViewById(R.id.button_personalize);

        myOrder = new CustomRide();
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mRideReqRef = mDatabase.getReference("rideRequests");

        mRideReqRefListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.w(TAG, "new ride requested");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "Failed to update requested rides", databaseError.toException());
            }
        };

        // [START declare_auth_listener]
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                    returnToMainActivity();
                }
            }
        };
        // [END auth_state_listener]

        Spinner spinner = (Spinner) findViewById(R.id.theme_song_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.theme_song_choices, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
        mRideReqRef.addValueEventListener(mRideReqRefListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    public void sendRideData(View view) {
        Log.d(TAG, "Adding new ride request");
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = user.getUid();
        myOrder.setRiderId(uid);
        String key = new Timestamp(System.currentTimeMillis()).toString();
        key = key.replace(".", "");
        key = key.replace("-", "");
        key = key.replace(":", "");
        Log.d(TAG, "New key = " + key);
        mDatabase.getReference("nextCustomRideId").setValue(key);
        mRideReqRef.child(key).setValue(myOrder);
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        switch (i) {
            case R.id.button_personalize:
                sendRideData(v);
                break;
            case R.id.bmw:
                if (!bmw_bold) {
                    v.setBackgroundResource(R.drawable.bold_bmw);
                    bmw_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_bmw);
                    bmw_bold = false;
                }
                break;
            case R.id.tesla:
                if (!tesla_bold) {
                    v.setBackgroundResource(R.drawable.bold_tesla);
                    tesla_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_tesla);
                    tesla_bold = false;
                }
                break;
            case R.id.honda:
                if (!honda_bold) {
                    v.setBackgroundResource(R.drawable.bold_honda);
                    honda_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_honda);
                    honda_bold = false;
                }
                break;
            case R.id.casual:
                if (!casual_bold) {
                    v.setBackgroundResource(R.drawable.bold_casual);
                    casual_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_casual);
                    casual_bold = false;
                }
                break;
            case R.id.suit:
                if (!suit_bold) {
                    v.setBackgroundResource(R.drawable.bold_suit);
                    suit_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_suit);
                    suit_bold = false;
                }
                break;
            case R.id.onesie:
                if (!onesie_bold) {
                    v.setBackgroundResource(R.drawable.bold_onesie);
                    onesie_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_onesie);
                    onesie_bold = false;
                }
                break;
            case R.id.button_laughter:
                if (!onesie_bold) {
                    v.setBackgroundResource(R.drawable.bold_laughter);
                    laughter_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_laughter);
                    laughter_bold = false;
                }
                break;
            case R.id.button_smile:
                if (!smile_bold) {
                    v.setBackgroundResource(R.drawable.bold_smile);
                    smile_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_smile);
                    smile_bold = false;
                }
                break;
            case R.id.button_frown:
                if (!frown_bold) {
                    v.setBackgroundResource(R.drawable.bold_frown);
                    frown_bold = true;
                } else {
                    v.setBackgroundResource(R.drawable.custom_frown);
                    frown_bold = false;
                }
                break;
        }
    }




}
