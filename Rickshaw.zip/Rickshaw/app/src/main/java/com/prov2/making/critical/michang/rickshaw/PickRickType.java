package com.prov2.making.critical.michang.rickshaw;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class PickRickType extends AppCompatActivity {

    private Button uberickX;
    private Button uberickPool;

    private boolean pool_selected = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_rick_type);
        uberickPool = (Button) findViewById(R.id.uberickPool);
        uberickX = (Button) findViewById(R.id.uberickX);
    }

    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.uberickPool && !pool_selected) {
            uberickPool.setBackgroundResource(R.drawable.uberick_pool_selected);
            uberickX.setBackgroundResource(R.drawable.uberickx_not_selected);
            pool_selected = true;
        } else if (i == R.id.uberickX && pool_selected) {
            uberickPool.setBackgroundResource(R.drawable.uberick_pool_not_selected);
            uberickX.setBackgroundResource(R.drawable.uberickx_selected);
            pool_selected = false;
        } else if (i == R.id.button_personalize) {
            Intent intent = new Intent(this, RideCustomization.class);
            startActivity(intent);
        }
    }
}
