package com.prov2.making.critical.michang.rickshaw;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

/**
 * Created by michang on 3/24/17.
 */

public class RideRequestDialog extends DialogFragment {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        String msg = getResources().getString(R.string.rideReqDest, "Chris", "Soda Hall");
        builder.setMessage(msg);
        builder.setTitle(R.string.rideReq);
        builder.setPositiveButton(R.string.accept, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Driver accepts ride
                Intent intent = new Intent(getActivity(), RideDetails.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton(R.string.deny, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Driver rejects ride
                RideRequestDialog.this.getDialog().cancel();
            }
        });

        AlertDialog dialog = builder.create();
//        try {
//            Log.d("RideRequestDialog", "Showing dialog");
//            this.show(getFragmentManager(), "RideRequestDialog");
//        } catch (NullPointerException e) {
//            Log.w("RideRequestDialog", e);
//        }

        return dialog;
    }

}
