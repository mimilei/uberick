package com.prov2.making.critical.michang.rickshaw;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.PopupWindow;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DriverMap extends FragmentActivity implements View.OnClickListener{

    private static final String TAG = "DriverMap";
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private DatabaseReference mRideReqRef;
    private DataSnapshot rideReqSnapshot;
    private ValueEventListener mRideReqRefListener;
    private FirebaseAuth.AuthStateListener mAuthListener;

    private String nextCustomRideId;
    private DatabaseReference nextCustomRideIdRef;
    private ValueEventListener nextCustomRideIdListener;
    private DataSnapshot nextCustomRideIdSnapshot;

    private CustomRide nextCustomRide;

    private PopupWindow rideReqPopup;

    private Button accept;
    private Button deny;

    // Add listener to ride requests
    // On new request, pop up window appears with accept/deny
    // Picture can be hard-coded

    private void returnToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_map);
        mAuth = FirebaseAuth.getInstance();

        mDatabase = FirebaseDatabase.getInstance();
        mRideReqRef = mDatabase.getReference("rideRequests");
        nextCustomRideIdRef = mDatabase.getReference("nextCustomRideId");

        nextCustomRideIdListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
//                nextCustomRideIdSnapshot = dataSnapshot;
                nextCustomRideId = dataSnapshot.getValue(String.class);
                Log.d(TAG, "new ride id found: " + nextCustomRideId);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "Failed to update nextCustomRideId", databaseError.toException());
            }
        };

        mRideReqRefListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    Log.w(TAG, "new ride requested");
                    rideReqSnapshot = dataSnapshot;

                    nextCustomRide = rideReqSnapshot.child(nextCustomRideId).getValue(CustomRide.class);
                    sendRideInfo();
                } catch (NullPointerException e) {
                    Log.w(TAG, "mRideReqRefListener: Issue sending ride information to driver: " + e);
                }
//                if (nextCustomRideId != null) {
//                    Log.w(TAG, "new ride requested");
//                    rideReqSnapshot = dataSnapshot;
//
//                    nextCustomRide = rideReqSnapshot.child(nextCustomRideId).getValue(CustomRide.class);
//                    sendRideInfo();
////                    int duration = Toast.LENGTH_LONG;
////                    Context context = getApplicationContext();
////                    Toast toast = Toast.makeText(context, nextCustomRide.riderId, duration);
////                    toast.show();
////                    toast = Toast.makeText(context, nextCustomRide.brand, duration);
////                    toast.show();
////                    toast = Toast.makeText(context, nextCustomRide.attire, duration);
////                    toast.show();
////                    toast = Toast.makeText(context, nextCustomRide.greeting, duration);
////                    toast.show();
////                    toast = Toast.makeText(context, nextCustomRide.themeSong, duration);
////                    toast.show();
//
//                    try {
//                        RideRequestDialog rideReqDialog = new RideRequestDialog();
////                        FragmentManager fm = getSupportFragmentManager();
////                        rideReqDialog.show(getSupportFragmentManager(), "RideRequestDialog");
//                    } catch (NullPointerException e) {
//                        Log.w("TRYING TO LAUNCH DIALOG", e);
//                    }
//                    showRideReqWindow();
//                } else {
//                    Log.w(TAG, "nextCustomRideId is null");
//                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "Failed to update requested rides", databaseError.toException());
            }
        };

        // [START declare_auth_listener]
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                    returnToMainActivity();
                }
            }
        };
        // [END auth_state_listener]
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
        nextCustomRideIdRef.addValueEventListener(nextCustomRideIdListener);
        mRideReqRef.addValueEventListener(mRideReqRefListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    public void signOut(View v) {
        mAuth.signOut();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void sendRideInfo() {
        Log.d("TRYING TO LAUNCH DIALOG", "Trying to send info to driver");
        if (rideReqSnapshot == null) {
            Log.w("TRYING TO LAUNCH DIALOG", "rideReqSnapshot is null");
        } else {
            nextCustomRide = rideReqSnapshot.child(nextCustomRideId).getValue(CustomRide.class);
            try {
                RideRequestDialog rideReqDialog = new RideRequestDialog();
//                FragmentManager fm = rideReqDialog.getFragmentManager();
                rideReqDialog.show(getFragmentManager(), "RideRequestDialog");
            } catch (NullPointerException e) {
                Log.w("TRYING TO LAUNCH DIALOG", e);
            }
        }
    }

//    public void showRideReqWindow() {
//        try {
//            LayoutInflater inflater = (LayoutInflater) DriverMap.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
////            View rideReqLayout = inflater.inflate(R.layout.activity_driver_map, (ViewGroup) findViewById(R.id.popup_rideRequest));
//            rideReqPopup = new PopupWindow(rideReqLayout, 300, 300, true);
//            Log.d(TAG, "created rideReqPopup");
//            rideReqPopup.showAtLocation(rideReqLayout, Gravity.CENTER, 0, 0);
//
//            deny = (Button) findViewById(R.id.button_deny);
//            accept = (Button) findViewById(R.id.button_accept);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    public void onClick(View v) {
//        int i = v.getId();
//        if (i == R.id.button_accept) {
//            rideReqPopup.dismiss();
//        } else if (i == R.id.button_deny) {
//            rideReqPopup.dismiss();
//        }
    }

}
