package com.prov2.making.critical.michang.rickshaw;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class WhereTo extends AppCompatActivity {

    // [START declare_auth]
    private FirebaseAuth mAuth;
    // [END declare_auth]

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_where_to);
        mAuth = FirebaseAuth.getInstance();
    }

    public void signOut(View v) {
        mAuth.signOut();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void setDest(View view) {
        //Temporary:
        Context context = getApplicationContext();
        CharSequence addr = "Nothing";
        switch (view.getId()) {
            case (R.id.dest_home):
                addr = "2520 Ridge Rd. Berkeley, Ca. 94709";
                break;
            case (R.id.dest_school):
                addr = "UC Berkeley";
                break;
            case (R.id.dest_asha):
                addr = "2086 University Ave, Berkeley, CA 94704";
                break;
        }
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, addr, duration);
        toast.show();

        Intent intent = new Intent(this, PickRickType.class);
        intent.putExtra("Destination", addr);
        startActivity(intent);
    }

//    @Override
//    public void onClick(View v) {
//        int i = v.getId();
//        if (i == R.id.button_logout) {
//            signOut();
//        }
//
//    }
}
