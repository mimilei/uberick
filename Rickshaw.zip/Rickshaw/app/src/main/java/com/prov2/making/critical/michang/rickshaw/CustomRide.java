package com.prov2.making.critical.michang.rickshaw;

/**
 * Created by michang on 3/22/17.
 */

public class CustomRide {
    public String brand;
    public String attire;
    public String greeting;
    public String themeSong;
    public String riderId;

    public CustomRide() { // Default constructor override
        this.brand = "BMW";
        this.attire = "Casual";
        this.greeting = "Laughter";
        this.themeSong = "Rollin";
        this.riderId = "Nothing";
    }

    public CustomRide(String i, String brand, String attire, String greeting, String themeSong) {
        this.riderId = i;
        this.brand = brand;
        this.attire = attire;
        this.greeting = greeting;
        this.themeSong = themeSong;
    }

    public void setRiderId(String i) {
        this.riderId = i;
    }

    public void setBrand(String b) {
        this.brand = b;
    }

    public void setAttire(String a) {
        this.attire = a;
    }

    public void setGreeting(String g) {
        this.greeting = g;
    }

    public void setThemeSong(String t) {
        this.themeSong = t;
    }
}
